alter table opc_partners
  add column if not exists hmac_key varchar(128);
alter table opc_partners
  alter column hmac_key type varchar(128);

alter table opc_partners
  add column if not exists api_key varchar(512);

comment on column opc_partners.hmac_key is 'Ключ для проверки подлинности сообщений';
comment on column opc_partners.api_key is 'Уникальный идентификатор, используемый для аутентификации';
