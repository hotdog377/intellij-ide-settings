DECLARE
  v_column_exists number := 0;
BEGIN
  select count(*) into v_column_exists
  from user_tab_cols
  where upper(column_name) = 'HMAC_KEY'
    and upper(table_name) = 'OPC_PARTNERS';

  if (v_column_exists = 0) then
    execute immediate 'alter table opc_partners add (hmac_key varchar2(128 char))';
    execute immediate 'comment on column opc_partners.hmac_key is ''Ключ для проверки подлинности сообщений''';
  else
    execute immediate 'alter table opc_partners modify (hmac_key varchar2(128 char))';
  end if;

  select count(*) into v_column_exists
  from user_tab_cols
  where upper(column_name) = 'API_KEY'
    and upper(table_name) = 'OPC_PARTNERS';

  if (v_column_exists = 0) then
    execute immediate 'alter table opc_partners add (api_key varchar2(512 char))';
    execute immediate 'comment on column opc_partners.api_key is ''Уникальный идентификатор, используемый для аутентификации''';
  end if;

  select count(*) into v_column_exists
  from user_tab_cols
  where upper(column_name) = 'HMAC_KEY'
    and upper(table_name) = 'OPC_MERCHANTS';

  if (v_column_exists = 0) then
    execute immediate 'alter table opc_merchants add (hmac_key varchar2(128 char))';
    execute immediate 'comment on column opc_merchants.hmac_key is ''Ключ для проверки подлинности сообщений''';
  end if;

  select count(*) into v_column_exists
  from user_tab_cols
  where upper(column_name) = 'API_KEY'
    and upper(table_name) = 'OPC_MERCHANTS';

  if (v_column_exists = 0) then
    execute immediate 'alter table opc_merchants add (api_key varchar2(512 char))';
    execute immediate 'comment on column opc_merchants.api_key is ''Уникальный идентификатор, используемый для аутентификации''';
  end if;
end;
